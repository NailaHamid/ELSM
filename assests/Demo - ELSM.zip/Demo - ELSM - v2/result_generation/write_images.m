% This file is part of ELSM by Naila Hamid and Nazar Khan.
% 
% ELSM is free software: you can redistribute it and/or modify
% it under the terms of the GNU v3.0 General Public License as published by
% the Free Software Foundation.
% 
% ELSM is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details
% <http://www.gnu.org/licenses/>.

function [ output_args ] = write_images( lines, im_r,name)
clf;
figure(1); cmap=colormap(jet); close;
hfig=figure(1); clf;axis off
imagesc(im_r); colormap gray;
hold on;axis off
drawlines(lines,cmap); drawnow;

axis image
set(hfig,'color','w');
set(gca,'position',[0 0 1 1],'units','normalized')
write_path=strcat(name);
saveas(gcf,write_path);
hold off;close
end