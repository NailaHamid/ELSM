% This file is part of ELSM by Naila Hamid and Nazar Khan.
% 
% ELSM is free software: you can redistribute it and/or modify
% it under the terms of the GNU v3.0 General Public License as published by
% the Free Software Foundation.
% 
% ELSM is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details
% <http://www.gnu.org/licenses/>.

function drawlines(lines,cmap)
a=1;
for j=1:size(lines,1)
    if mod(j,size(cmap,1))+1==0
        keyboard
    end
    line((lines(j,[1,3]))',(lines(j,[2,4])'),'Color',cmap(mod(a,size(cmap,1))+1,:),'LineWidth',1);
    a=a+2;
end