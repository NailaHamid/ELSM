% This file is part of ELSM by Naila Hamid and Nazar Khan.
% 
% ELSM is free software: you can redistribute it and/or modify
% it under the terms of the GNU v3.0 General Public License as published by
% the Free Software Foundation.
% 
% ELSM is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details
% <http://www.gnu.org/licenses/>.

function [M]=merge_two_lines(P,Q,tau_o,xi_s,tau_theta,pi_r,lengths,angles)
% This function takes P, Q segments and merge if they pass
% the criterion - Pseudo code line 14-28 checks are performed
% in this function

% give more importance to the longer of the two lines
% longer line is named P and angles are compared w.r.t P
% Pseudo code line 14-16
if lengths(2)>lengths(1)
    % Decision for using two vs. three references on P
    if pi_r==3
        tmp=P;
        P=Q;
        Q=tmp;
        Q{3}=P{3};
        P{3}=[-1 -1];
    elseif pi_r==2
        tmp=P;
        P=Q;
        Q=tmp;
        Q{3}=[-1 -1];
    end
    % swap lengths
    tmp=lengths(2);
    lengths(2)=lengths(1);
    lengths(1)=tmp;
    % swap angels
    tmp=angles(2);
    angles(2)=angles(1);
    angles(1)=tmp;
end

p1P=P{1}; p2P=P{2}; % first and second point of line segment P
p1Q=Q{1}; p2Q=Q{2}; % first and second point of line segment Q

if pi_r==3
    p3P=P{3}; % mid point of line segment P if using three references
end

l1=lengths(1); % length of line segment P
l2=lengths(2); % length of line segment Q
theta1=angles(1); % angle of line segment P
theta2=angles(2); % angle of line segment Q

%%%%Projection IDEA%%%%%%%
minP=min((P{1}(1)),(P{2}(1)));
maxP=max((P{1}(1)),(P{2}(1)));
minQ=min((Q{1}(1)),(Q{2}(1)));
maxQ=max((Q{1}(1)),(Q{2}(1)));
qx=maxQ-minQ;
if minP>=maxQ || maxP<=minQ
    ox=0;
elseif minP<=minQ && maxP>=maxQ
    ox=maxQ-minQ;
elseif minP<minQ && maxQ>maxP
    ox=maxP-minQ;
else
    ox=maxQ-minP;
end

minP=min((P{1}(2)),(P{2}(2)));
maxP=max((P{1}(2)),(P{2}(2)));
minQ=min((Q{1}(2)),(Q{2}(2)));
maxQ=max((Q{1}(2)),(Q{2}(2)));
qy=maxQ-minQ;
if minP>=maxQ || maxP<=minQ
    oy=0;
elseif minP<=minQ && maxP>=maxQ
    oy=maxQ-minQ;
elseif minP<minQ && maxQ>maxP
    oy=maxP-minQ;
else
    oy=maxQ-minP;
end

if ox>oy
    overlap=ox/qx;
else
    overlap=oy/qy;
end

M=-1;

% computing closest distance - Pseudo code line 17 
if pi_r==3
    dmat=[norm(p1P-p1Q) norm(p1P-p2Q) ; norm(p2P-p1Q) norm(p2P-p2Q) ; norm(p3P-p1Q) norm(p3P-p2Q) ];
    [d,i,j]=max2d(-dmat);
    dc=-d;
end

dmat=[norm(p1P-p1Q) norm(p1P-p2Q) ; norm(p2P-p1Q) norm(p2P-p2Q)];  
[d,i,j]=max2d(-dmat);
d=-d;
c1=P{i(1)}; c2=Q{j(1)};           % closest end-points of lines P and Q
L1o=P{2/i(1)}; L2o=Q{2/j(1)};     % other end points of P and Q

% Pseudo code line 19-23
if overlap<=tau_o
    tau_s=xi_s*l1;
else
    tau_s=xi_s*l1*(1-overlap);
end

if pi_r==3
    dis=dc;
elseif pi_r==2
    dis=d;
end

if dis<tau_s     
    % computing adaptive angular threshold - Pseudo Code line 25
    lambda=((l2/l1)+(d/tau_s));
    % 2--->skewness of logistic sigmoid
    tau_theta_star= (1-(1./(1+exp(-2*(lambda-1.5)))))*tau_theta; % 1.5--->1.5 out of 2 is assigned greater threshold.
    theta=abs(theta1-theta2);
    if theta < tau_theta_star || theta > pi-tau_theta_star
        % computing farthest end points for merged segment M - Pseudo Code line 27
        dist = [pdist2(c1,L1o) pdist2(c1,c2) pdist2(c1,L2o) pdist2(L1o,L2o) pdist2(L1o,c2) pdist2(c2,L2o) ];
        [max_dist max_ind]=max(dist);
        if max_ind==1
            M=[c1 L1o];
        elseif max_ind==2
            %can never happen
            M=[c1 c2];
        elseif max_ind==3
            M=[c1 L2o];
        elseif max_ind==4
            M=[L1o L2o];
        elseif max_ind==5
            M=[L1o c2];
        else
            %can never happen
            M=[c2 L2o];
        end
        
        if M~=-1
            % gradient of merged line should be similar to gradient of line P
            % final check on the absolute angular difference of the longer segment P and the merged segment M.
            % Pseudo Code line 28
            [gm m_dx m_dy]=line_gradient(M(1:2),M(3:4));
            thetaM=atan2(m_dy, m_dx);
            lengthM=sqrt(m_dx.^2+m_dy.^2);
         
            if thetaM<=0
                thetaM=thetaM+pi;
            end
            
            if abs(theta1-thetaM)<(tau_theta/2)
                M(5)=lengthM;
                M(6)=thetaM;
            else
                M=-1;
            end
        end
    else
        M=-1;
    end
else
    M=-1;
end

end

function [g dx dy]=line_gradient(p1,p2)
dx=p2(1)-p1(1);
if dx
    dy=p2(2)-p1(2);
    g=dy/dx;
else
    dy=p2(2)-p1(2);
    g=1e10;
end
end