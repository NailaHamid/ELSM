% This file is part of ELSM by Naila Hamid and Nazar Khan.
% 
% ELSM is free software: you can redistribute it and/or modify
% it under the terms of the GNU v3.0 General Public License as published by
% the Free Software Foundation.
% 
% ELSM is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details
% <http://www.gnu.org/licenses/>.

function [ L ] = merge_lines(D,h,w,pi_s,pi_t,pi_r,tau_theta,tau_o,tau_e)
% D contains the detected segments
% L will eventually have the set of merged line segments
L=D; % Pseudo code line 1,
     % setM is used in pseudo code for set of line segments and
     % M is used for a merged segment
     % Here we use L for set of merged segments and M for a merged segment

P=cell(1,3);
Q=cell(1,3);

% lengths and angles to use for merging process
[lengths,angles]=get_line_properties(L);

% lengths and angles to use for evidence
[lengthsD,anglesD]=get_line_properties(D);

x1D=D(:,1); x2D=D(:,3);
y1D=D(:,2); y2D=D(:,4);
num_lines=size(D,1);

while 1
    clear prf;
    % sort lines L in descending order of length - Pseudo code line 4
    [L lengths angles]=sort_lines_lengths(L,lengths,angles);
    
    % (x1,y1), (x2,y2) are the end points for each line segment in L
    x1=L(:,1); x2=L(:,3);
    y1=L(:,2); y2=L(:,4);

    % indP contains the index for line P and P is the selected line segment - Pseudo code line 5
    for indP=1:size(L,1)
        if indP>size(L,1)
            break;          %all lines have been processed
        end
        
        % Exhaustively merge current line and then remove it from the active set L
        angP=angles(indP); % it is the angle for line segment P
        
        % angular proximal lines - Pseudo Code line 8
        inds=find(abs(angles-angP)<tau_theta); % find lines with direction 'close to' angP
        inds=[inds ; find(abs(angles-angP)>(pi-2*pi/60))]; % to handle the wrap-around problem. (0,pi/60) should be compared with (pi-pi/60,pi)
        inds=setdiff(inds,indP); % inds contains indices for angular proximal lines w.r.t P
        
        if ~isempty(inds)
            cx1=x1(indP); cx2=x2(indP);
            cx3=(cx1+cx2)/2;
            cy1=y1(indP); cy2=y2(indP);
            cy3=(cy1+cy2)/2;
            % P contains 3 reference points, two end points and a mid point
            P{1}=[cx1 cy1];
            P{2}=[cx2 cy2];
            P{3}=[cx3 cy3];
            
            % adaptive spatial proximal threshold
            % Pseudo code line 7
            tau_s=pi_s*lengths(indP); 
            
            % spatial proximal lines from angular ones 
            % (inds contains indices for angular proximal lines)
            % Pseudo Code line 8
            x1diff=abs(repmat(cx1,length(inds),2)-[x1(inds) x2(inds)]);
            x2diff=abs(repmat(cx2,length(inds),2)-[x1(inds) x2(inds)]);
            x3diff=abs(repmat(cx3,length(inds),2)-[x1(inds) x2(inds)]);
 
            % inds1 contains angular + spatial proximal lines along x
            % This if-else structure decides to use two (endpoints) or 
            % three (endpoints+midpoint) references on the segment P
            if pi_r==3
                inds1=inds(any([x1diff x2diff x3diff]<tau_s,2));
            elseif pi_r==2
                inds1=inds(any([x1diff x2diff]<tau_s,2));
            end

            if isempty(inds1)
                continue
            end
            y1diff=abs(repmat(cy1,length(inds1),2)-[y1(inds1) y2(inds1)]);
            y2diff=abs(repmat(cy2,length(inds1),2)-[y1(inds1) y2(inds1)]);
            y3diff=abs(repmat(cy3,length(inds1),2)-[y1(inds1) y2(inds1)]);
            
            % inds2 contains final angular + spatial proximal lines
            % This if-else structure decides to use two (endpoints) or 
            % three (endpoints+midpoint) references on the segment P
            if pi_r==3
                inds2=inds1(any([y1diff y2diff y3diff]<tau_s,2));
            elseif pi_r==2
                inds2=inds1(any([y1diff y2diff]<tau_s,2));
            end
            
            % bad_inds contains the indices (for the segments that are merged in P)
            % to remove from L - Pseudo Code line 11
            bad_inds=[];
            
            % finding spatial and angular proximal group from detector
            % segments to use in image evidence - Pseudo code line 9
            indsD=find(abs(anglesD-angP)<tau_theta);
            indsD=[indsD ; find(abs(anglesD-angP)>(pi-2*pi/60))]; % to handle the wrap-around problem. (0,pi/60) should be compared with (pi-pi/60,pi)
            indsD=setdiff(indsD,indP);
            
            x1diff=abs(repmat(cx1,length(indsD),2)-[x1D(indsD) x2D(indsD)]);
            x2diff=abs(repmat(cx2,length(indsD),2)-[x1D(indsD) x2D(indsD)]);
            x3diff=abs(repmat(cx3,length(indsD),2)-[x1D(indsD) x2D(indsD)]);
            
            if pi_r==3
                inds1D=indsD(any([x1diff x2diff x3diff]<tau_s,2));
            elseif pi_r==2
                inds1D=indsD(any([x1diff x2diff]<tau_s,2));
            end
            if isempty(inds1D)
                continue
            end
            y1diff=abs(repmat(cy1,length(inds1D),2)-[y1D(inds1D) y2D(inds1D)]);
            y2diff=abs(repmat(cy2,length(inds1D),2)-[y1D(inds1D) y2D(inds1D)]);
            y3diff=abs(repmat(cy3,length(inds1D),2)-[y1D(inds1D) y2D(inds1D)]);
           
            if pi_r==3
                inds2D=inds1D(any([y1diff y2diff y3diff]<tau_s,2));
            elseif pi_r==2
                inds2D=inds1D(any([y1diff y2diff]<tau_s,2));
            end
            % Making evidence image for P w.r.t spatial and angular proximal group
            % taken from D - Pseudo code line 10
            % pi_t is the parameter to define thickness to use in evidence
            % image generation, here we use pi_t=1 always which thickens
            % segments by 3 pixels
                winSize=pi_t;
                lineSet=D( [inds2D] ,:);
                
                E=zeros([h w]);
                for ls=1:size(lineSet,1)
                    [lx ly lc]=improfile(E,[lineSet(ls,1),lineSet(ls,3)],[lineSet(ls,2),lineSet(ls,4)]);
                    lx=round(lx);
                    ly=round(ly);
                    for ll=1:size(lx,1)
                        if (lx(ll)>0 && ly(ll)>0 && lx(ll)<size(E,2) && ly(ll)<size(E,1))
                            E(   ly(ll)  ,  lx(ll)  )=1;
                        end
                        up  = ly(ll)-winSize; % lower row index of window
                        down  = ly(ll)+winSize; % upper row index of window
                        left  = lx(ll)-winSize; % lower column index of window
                        right  = lx(ll)+winSize; % upper column index of window
                        if(up>0 && left>0 && left<size(E,2) && right<size(E,2))
                            E(up,lx(ll))=1;
                            E(down,lx(ll))=1;
                            E(ly(ll),left)=1;
                            E(ly(ll),right)=1;
                        end
                    end
                end
            
            % As inds2 contains indices for spatial + angular proximal group
            % from set L for selected segment P, each segment from group is
            % selected as Q and merged with P if passes the criterion
            % Pseudo code line 12
            for jj=1:length(inds2) 
                % indQ contains index for Q and Q is the selected line segment to merge in P
                indQ=inds2(jj);
                % Q contains the endpoints (P can have 2 or 3 references,
                % while Q considers two reference that are endpoints only)
                Q{1}=[x1(indQ) y1(indQ)];
                Q{2}=[x2(indQ) y2(indQ)];
                
                % This function takes P, Q segments and merge if they pass
                % the criterion - Pseudo code line 14-28 checks are performed
                % in this function
                [M]=merge_two_lines(P,Q,tau_o,pi_s,tau_theta,pi_r,lengths([indP,indQ]),angles([indP,indQ]));
                
                % if M is not empty that means it contains a merged segment
                % compute evidence value and apply threshold - Pseudo Code line 29-33
                if length(M)>1 
                    [lx ly eM]=improfile(E,[M(1),M(3)],[M(2),M(4)]);
                    if (mean(eM)>tau_e)                        
                        L(indP,:)=[M(1:4) mean(L([indP,indQ],5))];
                        lengths(indP)=M(5);
                        angles(indP)=M(6);
                        P{1}=M(1:2);
                        P{2}=M(3:4);
                        if pi_r==3
                            P{3}=[(M(1)+M(3))/2 (M(2)+M(4))/2];
                        end

                        % store indices of all Q's to be removed from the set L
                        bad_inds=[bad_inds indQ]; % bad_inds contains the indices to remove from set of lines L
                    end
                end
            end
            
            % removing indices of merged lines, all Q's are merged in P - Pseudo Code line 38
            good_inds=setdiff(1:size(L,1),bad_inds); 
            L=L(good_inds,:); % L now contains the merged line replacing P, respective Q lines being merged are removed from L
            
            % updating the endpoints x1, x2, y1, y2
            % lengths and angles for new L
            lengths=lengths(good_inds,:);
            angles=angles(good_inds,:);   
            x1=L(:,1); x2=L(:,3);
            y1=L(:,2); y2=L(:,4);
        end
    end
    if size(L,1)==num_lines
        break;  % line merging has converged
    else
        num_lines=size(L,1);
    end
end