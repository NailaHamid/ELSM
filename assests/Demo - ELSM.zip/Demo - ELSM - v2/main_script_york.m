% This file is part of ELSM by Naila Hamid and Nazar Khan.
% 
% ELSM is free software: you can redistribute it and/or modify
% it under the terms of the GNU v3.0 General Public License as published by
% the Free Software Foundation.
% 
% ELSM is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details
% <http://www.gnu.org/licenses/>.


clear;
close all;
clc;
addpath(genpath(pwd));

%****THRESHOLD AND PARAMETER SETTING***%
pi_s=.05;   % spatial proximity: range [0 to 1]
pi_t=1;     % thickness for line segment evidence: value 1 is used always in this version
pi_r=2;     % number of reference points for spatial proximity: value 2 for YorkUrbanDB, value 3 for line drawings

tau_theta=pi/36; % angular proximity: range [greater than 0 degree]
tau_o=.6;        % overlap tolerance: range [0 to 1]
tau_e=.8;        % line segment evidence: range [0 to 1]

%Detection by LSD
I_orig=imread('P1080079.jpg');
I=double(rgb2gray(I_orig));

lines=[];
lines=[lines;lsd(I/max(I(:))*255)];

%Merging by ELSM
[lines_merged]=merge_lines(lines,size(I,1), size(I,2),pi_s,pi_t,pi_r,tau_theta,tau_o,tau_e);

%Displaying and writing result
write_images(lines,I_orig,strcat('P1080079_lsd_',int2str(size(lines,1)),'.pdf'));
write_images(lines_merged,I_orig,strcat('P1080079_elsm_',int2str(size(lines_merged,1)),'.pdf'));
n_lines_lsd=size(lines,1);
n_lines_lsdm=size(lines_merged,1);
[n_lines_lsd n_lines_lsdm]