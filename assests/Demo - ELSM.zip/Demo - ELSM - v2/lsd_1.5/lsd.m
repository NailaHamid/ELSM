%function lines=lsd(im)
%INPUT
%	im: double valued gray image
%OUTPUT
%	lines<Nx5>: line segments found in im, x1 y1 x2 y2 width
